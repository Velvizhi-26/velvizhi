// JavaScript for password strength validation and error message display
const passwordInput = document.getElementById("password");
const passwordStrength = document.getElementById("password-strength");
const errorMessage = document.getElementById("error-message");
const loginForm = document.getElementById("login-form");

passwordInput.addEventListener("input", validatePassword);
loginForm.addEventListener("submit", handleFormSubmit);

function validatePassword() {
  const password = passwordInput.value;
  const strength = calculatePasswordStrength(password);
  
  if (password.length === 0) {
    passwordStrength.textContent = "";
  } else {
    passwordStrength.textContent = "Password Strength: " + strength;
  }
}

function calculatePasswordStrength(password) {
  let strength = 0;

  if (password.length >= 8) {
    strength++;
  }

  if (password.match(/[a-z]/) && password.match(/[A-Z]/)) {
    strength++;
  }

  if (password.match(/\d+/)) {
    strength++;
  }

  if (password.match(/[!@#$%^&*(),.?":{}|<>]/)) {
    strength++;
  }

  switch (strength) {
    case 0:
    case 1:
      return "Weak";
    case 2:
      return "Moderate";
    case 3:
    case 4:
      return "Strong";
    default:
      return "";
  }
}

function handleFormSubmit(event) {
  event.preventDefault();
  
  const usernameInput = document.getElementById("username");
  const password = passwordInput.value;
  const username = usernameInput.value;

  // Reset error message
  errorMessage.textContent = "";

  // Validate form inputs
  if (username.trim() === "" || password.trim() === "") {
    errorMessage.textContent = "Username and password are required.";
    return;
  }

  if (password.length < 8) {
    errorMessage.textContent = "Password must be at least 8 characters long.";
    return;
  }

  const strength = calculatePasswordStrength(password);
  if (strength === "Weak") {
    errorMessage.textContent = "Password is too weak.";
    return;
  }

  // Perform login logic here
  if (username === "admin" && password === "password123") {
    // Successful login
    alert("Login successful! Redirecting to the dashboard...");
    window.location.href = "dashboard.html"; // Replace with the desired destination page

    // Redirect to the dashboard or another page
  } else {
    // Failed login
    errorMessage.textContent = "Invalid username or password.";
  }

}
