<?php

$str = "touch mark";
$string = reverseString($str);
echo $string;

function reverseString($str) {
$length = strlen($str);
$reversed = '';

for ($i = $length - 1; $i >= 0; $i--) {
    $reversed .= $str[$i]; // add string using .
}

return $reversed;

}
?>