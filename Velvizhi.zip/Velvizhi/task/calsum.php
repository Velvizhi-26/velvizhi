<?php 
$numbers = [1, 2, 3, 4, 5];
$result = calculateSum($numbers);
echo $result;

function calculateSum($numbers) {
$sum = 0;

foreach ($numbers as $number) {
    $sum += $number;
}

return $sum;

}
?>