1. SELECT orders.order_id, orders.order_date, customers.customer_name FROM orders 
INNER JOIN customers ON orders.customer_id = customers.customer_id

2. SELECT COUNT(product_id) as total_sales FROM sales GROUP BY product_id

3. SELECT orders.order_id, customers.customer_name, products.product_name FROM orders
INNER JOIN customers ON orders.customer_id = customers.customer_id 
INNER JOIN products ON orders.product_id = products.product_id

4. SELECT COUNT(*) as total_orders, sum(order_total) as total_sales FROM total_orders

5. SELECT customer_name, order_date FROM customers WHERE customer_id IN 
(SELECT customer_id FROM orders WHERE order_total > 100)