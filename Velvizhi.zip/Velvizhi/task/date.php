<?php 
$date = "17 jun 1998";
$result = formatDate($date);
echo $result;
function formatDate($date) {
$condate = date("m/d/Y" ,strtotime($date));
return $condate;

}
?>