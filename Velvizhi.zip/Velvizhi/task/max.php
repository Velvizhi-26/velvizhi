<?php 
$arr = [1, 2, 3, 4, 5];
$result = findMax($arr);
echo $result;
function findMax($arr) {
$max = 0;

foreach ($arr as $num) {
    if ($num > $max) {
        $max = $num;
    }
}

return $max;

}
?>